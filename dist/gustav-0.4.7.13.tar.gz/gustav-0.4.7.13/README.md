[![Build Status](https://travis-ci.org/cbrown1/gustav.svg?branch=master)](https://travis-ci.org/cbrown1/gustav)

# gustav

A python module to help with conducting psychophysical experiments 

## Installing

### Download:

```bash
git clone https://github.com/cbrown1/gustav.git
```

### Compile and install:

```bash
python setup.py build
sudo python setup.py install
```

## Authors

- **Christopher Brown**

## License

This project is licensed under the GPLv3 - see the [LICENSE.md](LICENSE.md) file for details.
